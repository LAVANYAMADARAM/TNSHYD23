package x1;
public class A //protected access modifier
{
protected void display()
{
	System.out.println("TNS SESSIONS");
}
}
