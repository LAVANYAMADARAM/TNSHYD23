package p1;
//public access modifiers
public class A {
public void display()
{
	System.out.println("Tns session");
}
}
