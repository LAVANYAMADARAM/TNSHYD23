package t1;
//default access modifier
 class MyClass1 {
void display()
	{
System.out.println("hello world");
	}
}
