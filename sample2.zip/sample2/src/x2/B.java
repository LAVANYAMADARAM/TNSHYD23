package x2;
import x1.*;
public class B extends A//protected access modifier
{
	public static void main(String[] args)
	{
	B obj=new B();	
	obj.display();
     }
}
