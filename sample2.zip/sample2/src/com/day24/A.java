package com.day24;
//private access modifier
 class A {
	private void display()
	{
		System.out.println("Tns Session");
	}

}
