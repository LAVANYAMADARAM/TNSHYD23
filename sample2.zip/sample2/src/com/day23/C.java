package com.day23;

public class C {
int b=20;
static int c=30;
int display() {
	return 10;
}
static void dispaly1() {
	System.out.println(10);
}
}




