package com.day23;

public class D {

	public static void main(String[] args) {
		int a=29;
		System.out.println(a);
	C b1=new C();
	System.out.println(b1.c);
	b1.display();
System.out.println(C.c);
C.dispaly1();
}
}
