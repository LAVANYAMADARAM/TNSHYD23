package pack;

public class A {

}
